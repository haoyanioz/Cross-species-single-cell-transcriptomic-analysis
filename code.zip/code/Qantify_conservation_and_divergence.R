####################Quantify conserved and divergent gene expression for heart across species
set_k <- 9
celltype="CM" #also for FB and EC
avg_exp_ALL_sub1 <- read.table(paste0("heart.",celltype,".rank.xls"),sep="\t",header=TRUE,row.names=1)
set.seed(123)
best_kmeans_result <- kmeans(avg_exp_ALL_sub1, centers = set_k, nstart = 25)
cluster_assignment <- best_kmeans_result$cluster
sorted_data <- avg_exp_ALL_sub1[order(cluster_assignment), ]
cluster_num <- as.data.frame(table(cluster_assignment))
colnames(cluster_num) <- c("cluster","Num")
cluster_num
avg_exp=sorted_data
Ndegs=cluster_num
dim(avg_exp)
write.table(sorted_data,paste0("heart.",celltype,".rank.sorted.",set_k,".xls"),quote=FALSE,sep="\t",row.names=TRUE,col.names=TRUE)
write.table(cluster_num,paste0("heart.",celltype,".rank.sorted.gene_number.",set_k,".xls"),quote=FALSE,sep="\t",row.names=FALSE,col.names=TRUE)


####################Quantify conserved and divergent gene expression for lung across species
set_k <- 9
celltype="AT1" #also for AT2, CC, FB, and EC
avg_exp_ALL_sub2 <- read.table(paste0("lung.",celltype,".rank.xls"),sep="\t",header=TRUE,row.names=1)
set.seed(123)
best_kmeans_result <- kmeans(avg_exp_ALL_sub2, centers = set_k, nstart = 25)
cluster_assignment <- best_kmeans_result$cluster
sorted_data <- avg_exp_ALL_sub2[order(cluster_assignment), ]
cluster_num <- as.data.frame(table(cluster_assignment))
colnames(cluster_num) <- c("cluster","Num")
cluster_num
avg_exp=sorted_data
Ndegs=cluster_num
dim(avg_exp)
write.table(sorted_data,paste0("lung.",celltype,".rank.sorted.",set_k,".xls"),quote=FALSE,sep="\t",row.names=TRUE,col.names=TRUE)
write.table(cluster_num,paste0("lung.",celltype,".rank.sorted.gene_number.",set_k,".xls"),quote=FALSE,sep="\t",row.names=FALSE,col.names=TRUE)

