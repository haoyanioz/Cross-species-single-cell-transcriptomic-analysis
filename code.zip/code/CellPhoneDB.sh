####################For lung neonates and adults of human, mouse, and tree sparrow
conda activate cpdb

for comp in {adult_human_rmRBCTHC,adult_mouse_rmRBCTHC,adult_treesparrow_rmRBCTHC,neonatal_human_rmRBCTHC,neonatal_mouse_rmRBCTHC,neonatal_treesparrow_rmRBCTHC}
do
head -1 lung_${comp}_RNA.data.xls > lung_${comp}_RNA.data.head.xls
sed -i "s/^/Gene\t/g" lung_${comp}_RNA.data.head.xls
sed '1d' lung_${comp}_RNA.data.xls > lung_${comp}_RNA.data.rmhead.xls
cat lung_${comp}_RNA.data.head.xls lung_${comp}_RNA.data.rmhead.xls > lung_${comp}_RNA.data_rename2.xls
grep -v '^None' lung_${comp}_RNA.data_rename2.xls > CellPhoneDB_counts_lung_${comp}.txt
sed -i 's/PT/AT/g' lung_${comp}_sampleinfo.xls
cut -f1,4 lung_${comp}_sampleinfo.xls > lung_${comp}_sampleinfo2.xls
sed -i '1d' lung_${comp}_sampleinfo2.xls
sed -i 's/ /_/g' lung_${comp}_sampleinfo2.xls
sed '1i Cell\tcell_type' lung_${comp}_sampleinfo2.xls > CellPhoneDB_meta_lung_${comp}.txt
rm lung_${comp}_sampleinfo2.xls
cellphonedb method statistical_analysis CellPhoneDB_meta_lung_${comp}.txt CellPhoneDB_counts_lung_${comp}.txt --counts-data hgnc_symbol --threshold 0.1 --iterations 1000 --pvalue 0.05 --threads 120
mv out out_${comp}_it1000
done
