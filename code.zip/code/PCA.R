####################PCA for lung neonates and adults of human, mouse, and tree sparrow
library(gmodels)
library(ggplot2)
sampleInfo <- read.table(paste0("lung_sampleInfo.txt"),sep="\t",header=TRUE,row.names=NULL,quote="")
cls_ord <- c("AT1","AT2","FB","EC","CC")
for(celltype in cls_ord){ 
inname = paste0("lung.",celltype,".t.rank.xls")
outname = paste0("lung.",celltype,".log2.rank.pdf")
outname2 = paste0("lung.",celltype,".log2_name.rank.pdf")
data <- read.table(inname, header=F, row.names=1,sep="\t",quote="")
rownames(data)
rownames(data) <- sub(".*?_", "", rownames(data))
rownames(data)
rownames(data) <- sub(".*?_", "", rownames(data))
rownames(data)
data.pca <- fast.prcomp(log2(na.omit(data)+1),retx=T,scale=T,center=T)
Species <- sampleInfo$Species[match(rownames(data), sampleInfo$Sample)]
Development <- sampleInfo$Development[match(rownames(data), sampleInfo$Sample)]
Info=paste0(Species,"_",Development,"_",rownames(data))
a <- summary(data.pca)
tmp <- a[4]$importance
pro1 <- as.numeric(sprintf("%.4f",tmp[2,1]))*100
pro2 <- as.numeric(sprintf("%.4f",tmp[2,2]))*100
pc = as.data.frame(a$x)
pc$names = rownames(pc)
pc$Species = Species
pc$Development = Development
xlab=paste("PC1(",pro1,"%)",sep="") 
ylab=paste("PC2(",pro2,"%)",sep="")
pca=ggplot(pc,aes(PC1,PC2)) + 
    geom_point(size=6,aes(color=Species,shape=Development)) +
    labs(x=xlab,y=ylab,title="PCA") + 
    geom_hline(yintercept=0,linetype=4,color="grey") + 
    geom_vline(xintercept=0,linetype=4,color="grey") +
    #geom_text(aes(label=names),size=3)+
    theme_bw()+theme(axis.title = element_text(size=16, color="black"),axis.text= element_text(size=16, color="black"),legend.title = element_blank(), legend.text= element_text(size=16, color="black")) 
ggsave(outname,pca,width=10,height=8)
pca2=ggplot(pc,aes(PC1,PC2)) + 
    geom_point(size=6,aes(color=Species,shape=Development)) +
    labs(x=xlab,y=ylab,title="PCA") + 
    geom_hline(yintercept=0,linetype=4,color="grey") + 
    geom_vline(xintercept=0,linetype=4,color="grey") +
    geom_text(aes(label=names),size=3)+
    theme_bw()+theme(axis.title = element_text(size=16, color="black"),axis.text= element_text(size=16, color="black"),legend.title = element_blank(), legend.text= element_text(size=16, color="black")) 
ggsave(outname2,pca2,width=10,height=8)
write.table(pc,file=paste0("lung.",celltype,".log2.scores.rank.xls"),quote=FALSE,sep="\t",row.names=FALSE)
write.table(a$rotation,file=paste0("lung.",celltype,".log2.loadings.rank.xls"),quote=FALSE,sep="\t",row.names=TRUE)
}