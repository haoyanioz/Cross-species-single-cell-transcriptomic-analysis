####################For heart single cells of neonates
for (file in c("LEhc1", "LEhc2", "LEhc3", "LEhc4", "HEhc1", "HEhc2", "HEhc3", "HEhc4", "HEhc5")){
    assign(file, readRDS(file = paste0("../../",file,"_DoubletFinder_filtered.rds")))
    tmp<-get(file)
    tmp$log10GenesPerUMI <- log10(tmp$nFeature_RNA) / log10(tmp$nCount_RNA)
    tmp$mitoRatio <- PercentageFeatureSet(object = tmp, pattern = "^MT-")
    tmp$mitoRatio <- tmp@meta.data$mitoRatio / 100
    ribo_gene<-read.table("../ribo.gene",header = FALSE,sep = "\t",row.names=NULL)
    HB_gene<-read.table("../HB.gene",header = FALSE,sep = "\t",row.names=NULL)
    MT_gene <- rownames(tmp[grep("^MT-",rownames(tmp))])
    percent.ribo <- Matrix::colSums(tmp[as.array(ribo_gene[,1]),])/Matrix::colSums(tmp)
    percent.HB <- Matrix::colSums(tmp[as.array(HB_gene[,1]),])/Matrix::colSums(tmp)

    tmp <- AddMetaData(tmp, percent.ribo, col.name = "riboRatio")
    tmp <- AddMetaData(tmp, percent.HB, col.name = "HBRatio")

    metadata <- tmp@meta.data
    metadata$cells <- rownames(metadata)
    metadata <- metadata %>%
        dplyr::rename(seq_folder = orig.ident,
                      nUMI = nCount_RNA,
                      nGene = nFeature_RNA)
    metadata$sample <- file
    tmp@meta.data <- metadata
    filtered_seurat <- subset(x = tmp, 
                              (nGene >= 100) & 
                              (log10GenesPerUMI > 0.7) & 
                              (mitoRatio < 0.40) & 
                              (riboRatio < 0.20))

    counts <- GetAssayData(object = filtered_seurat, slot = "counts")
    nonzero <- counts > 0
    keep_genes <- Matrix::rowSums(nonzero) >= 10
    filtered_counts <- counts[keep_genes, ]
    filtered_seurat <- CreateSeuratObject(filtered_counts, meta.data = filtered_seurat@meta.data)
    metadata_clean <- filtered_seurat@meta.data
    print(filtered_seurat)
    save(filtered_seurat, file=paste0("./QC_",file,"_filtered.RData"))
}


####################For heart single nuclei of adults
for (file in c("LAhn1", "LAhn2", "LAhn3", "HAhn1", "HAhn2", "HAhn3")){
    assign(file, readRDS(file = paste0("../../",file,"_DoubletFinder_filtered.rds")))
    tmp<-get(file)
    tmp$log10GenesPerUMI <- log10(tmp$nFeature_RNA) / log10(tmp$nCount_RNA)
    tmp$mitoRatio <- PercentageFeatureSet(object = tmp, pattern = "^MT-")
    tmp$mitoRatio <- tmp@meta.data$mitoRatio / 100
    ribo_gene<-read.table("../ribo.gene",header = FALSE,sep = "\t",row.names=NULL)
    HB_gene<-read.table("../HB.gene",header = FALSE,sep = "\t",row.names=NULL)
    MT_gene <- rownames(tmp[grep("^MT-",rownames(tmp))])
    percent.ribo <- Matrix::colSums(tmp[as.array(ribo_gene[,1]),])/Matrix::colSums(tmp)
    percent.HB <- Matrix::colSums(tmp[as.array(HB_gene[,1]),])/Matrix::colSums(tmp)

    tmp <- AddMetaData(tmp, percent.ribo, col.name = "riboRatio")
    tmp <- AddMetaData(tmp, percent.HB, col.name = "HBRatio")

    metadata <- tmp@meta.data
    metadata$cells <- rownames(metadata)
    metadata <- metadata %>%
        dplyr::rename(seq_folder = orig.ident,
                      nUMI = nCount_RNA,
                      nGene = nFeature_RNA)
    metadata$sample <- file
    tmp@meta.data <- metadata
    filtered_seurat <- subset(x = tmp, 
                              (nGene >= 100) & 
                              (log10GenesPerUMI > 0.7) & 
                              (mitoRatio < 0.20) & 
                              (riboRatio < 0.05))

    counts <- GetAssayData(object = filtered_seurat, slot = "counts")
    nonzero <- counts > 0
    keep_genes <- Matrix::rowSums(nonzero) >= 10
    filtered_counts <- counts[keep_genes, ]
    filtered_seurat <- CreateSeuratObject(filtered_counts, meta.data = filtered_seurat@meta.data)
    metadata_clean <- filtered_seurat@meta.data
    print(filtered_seurat)
    save(filtered_seurat, file=paste0("./QC_",file,"_filtered.RData"))
}


####################For lung single cells of neonates and adults
for (file in c("LElc1", "LElc2", "LElc3", "LAlc1", "LAlc2", "LAlc3", "HElc1", "HElc2", "HElc3", "HAlc1", "HAlc2", "HAlc3", "HAlc4")){
    assign(file, readRDS(file = paste0("../../",file,"_DoubletFinder_filtered.rds")))
    tmp<-get(file)
    tmp$log10GenesPerUMI <- log10(tmp$nFeature_RNA) / log10(tmp$nCount_RNA)
    tmp$mitoRatio <- PercentageFeatureSet(object = tmp, pattern = "^MT-")
    tmp$mitoRatio <- tmp@meta.data$mitoRatio / 100
    ribo_gene<-read.table("../ribo.gene",header = FALSE,sep = "\t",row.names=NULL)
    HB_gene<-read.table("../HB.gene",header = FALSE,sep = "\t",row.names=NULL)
    MT_gene <- rownames(tmp[grep("^MT-",rownames(tmp))])
    percent.ribo <- Matrix::colSums(tmp[as.array(ribo_gene[,1]),])/Matrix::colSums(tmp)
    percent.HB <- Matrix::colSums(tmp[as.array(HB_gene[,1]),])/Matrix::colSums(tmp)

    tmp <- AddMetaData(tmp, percent.ribo, col.name = "riboRatio")
    tmp <- AddMetaData(tmp, percent.HB, col.name = "HBRatio")

    metadata <- tmp@meta.data
    metadata$cells <- rownames(metadata)
    metadata <- metadata %>%
        dplyr::rename(seq_folder = orig.ident,
                      nUMI = nCount_RNA,
                      nGene = nFeature_RNA)
    metadata$sample <- file
    tmp@meta.data <- metadata
    filtered_seurat <- subset(x = tmp, 
                              (nGene >= 100) & 
                              (log10GenesPerUMI > 0.7) & 
                              (mitoRatio < 0.5)& 
                              (riboRatio < 0.2)) 

    counts <- GetAssayData(object = filtered_seurat, slot = "counts")
    nonzero <- counts > 0
    keep_genes <- Matrix::rowSums(nonzero) >= 10
    filtered_counts <- counts[keep_genes, ]
    filtered_seurat <- CreateSeuratObject(filtered_counts, meta.data = filtered_seurat@meta.data)
    metadata_clean <- filtered_seurat@meta.data
    print(filtered_seurat)
    save(filtered_seurat, file=paste0("./QC_",file,"_filtered.RData"))
}

