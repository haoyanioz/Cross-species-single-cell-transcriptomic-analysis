#!/usr/bin/env python
# coding: utf-8

# In[ ]:





# In[ ]:


## CAME can be downloaded from https://github.com/XingyanLiu/CAME


# In[1]:


import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt  # optional
import seaborn as sns  # optional

import scanpy as sc
from scipy import sparse

import networkx as nx
import torch

# CAME_ROOT = Path('path/to/CAME')
# sys.path.append(str(CAME_ROOT))

import came
from came import pipeline, pp, pl

ROOT = Path(".")  # set root

# ========= customized paths ==========
# path_rawdata1 = CAME_ROOT / 'came/sample_data/raw-Baron_human.h5ad'
# path_rawdata2 = CAME_ROOT / 'came/sample_data/raw-Baron_mouse.h5ad'
# homedir = "/bigdata0"
homedir = ""


# In[2]:


# path_varmap = '/mnt/disk1/xzhou/data/cross_species/treesparrow/gene_matches_human2treesparrow105_newgenome.csv'
path_varmap = '/mnt/disk1/xzhou/data/cross_species/treesparrow/gene_matches_mouse2treesparrow105_newgenome.csv'

path_varmap_1v1 = False

# ========= load data =========
df_varmap = pd.read_csv(path_varmap)
df_varmap_1v1 = pd.read_csv(path_varmap_1v1) if path_varmap_1v1 else came.pp.take_1v1_matches(df_varmap)


# In[3]:


adata_raw1=sc.read_h5ad("MCA_TMS_concat.h5ad")
adata_raw1.obs[['cell_ontology_class',"Batch_name"]]=pd.read_csv("MCA_TMS_concat_metadata.csv", index_col=0)
import scipy.sparse as sp
adata = sc.AnnData(sp.csr_matrix(adata_raw1.X, dtype=np.float32))
adata.obs_names = adata_raw1.obs_names
adata.var_names = adata_raw1.var_names
adata.obs['cell_ontology_class'] = adata_raw1.obs['cell_ontology_class']
adata_raw1 = adata.copy()

adata_raw1 = adata_raw1[adata_raw1.obs['cell_ontology_class'].isin(['AT2','Endothelial','AT1','Fibroblast','Smooth muscle'])]


# In[4]:


from came.utils.base import subsample_each_group
n_subsample = 1000
indices = subsample_each_group(adata_raw1.obs['cell_ontology_class'], n_out=n_subsample)
adata_raw1 = adata_raw1[indices]


# In[5]:


adata_raw1.obs['cell_ontology_class'].value_counts()


# In[ ]:


adata_raw2 = sc.read_h5ad("lung.h5ad")
adata_raw2.obs['cell_ontology_class'] = adata_raw2.obs['Identity']
adata_raw2.obs['cell_ontology_class'][adata_raw2.obs['cell_ontology_class']=="PT1"] = "AT1"
adata_raw2.obs['cell_ontology_class'][adata_raw2.obs['cell_ontology_class']=="PT2"] = "AT2"
adata_raw2.obs['cell_ontology_class'][adata_raw2.obs['cell_ontology_class']=="SMC"] = "Smooth muscle"
adata_raw2.obs['cell_ontology_class'][adata_raw2.obs['cell_ontology_class']=="EC"] = "Endothelial"
adata_raw2.obs['cell_ontology_class'][adata_raw2.obs['cell_ontology_class']=="FB"] = "Fibroblast"
adata_raw2.obs['cell_ontology_class'][adata_raw2.obs['cell_ontology_class']=="MNC"] = "Monocyte"
adata_raw2.obs['cell_ontology_class'][adata_raw2.obs['cell_ontology_class']=="BC"] = "B cell"
adata_raw2.obs['cell_ontology_class'][adata_raw2.obs['cell_ontology_class']=="TC"] = "T cell"
adata_raw2.obs['cell_ontology_class'][adata_raw2.obs['cell_ontology_class']=="PC"] = "Pericyte"
adata_raw2.obs['cell_ontology_class'][adata_raw2.obs['cell_ontology_class']=="CC"] = "Ciliated"
adata_raw2.obs['cell_ontology_class'][adata_raw2.obs['cell_ontology_class']=="MP"] = "Macrophage"
adata_raw2.obs['cell_ontology_class'][adata_raw2.obs['cell_ontology_class']=="MSC"] = "Mast"
adata_raw2.obs['cell_ontology_class'][adata_raw2.obs['cell_ontology_class']=="DC"] = "Dendritic"

adata_raw2 = adata_raw2[adata_raw2.obs['Sample'].isin(['LAlc1', 'LAlc2', 'LAlc3'])]
adata_raw2.var_names = adata_raw2.var['features']
adata_raw2.raw = None

adata_raw2 = adata_raw2[adata_raw2.obs['cell_ontology_class'].isin(['AT1','AT2','Smooth muscle','Fibroblast','Endothelial'])]


# In[7]:


adata_raw2.obs['cell_ontology_class'].value_counts()


# In[ ]:





# In[8]:


adatas = [adata_raw1.copy(), adata_raw2.copy()]

# dsnames = ('Human_embryo', 'Treesparrow_Neonatal')  # set by user
# dsnames = ('Human_Adult_lung', 'Treesparrow_Adult_lung')  # set by user
# dsnames = ('Mouse_Neonatal', 'Treesparrow_Neonatal')  # set by user
dsnames = ('Mouse_Adult', 'Treesparrow_Adult')  # set by user

dsn1, dsn2 = dsnames

key_class1 = 'cell_ontology_class'  # set by user
key_class2 = 'cell_ontology_class'  # set by user

#Setting directory for results
time_tag = came.make_nowtime_tag()
# resdir = ROOT /'_temp' / f'{dsnames}-{time_tag}_heart'  # set by user
resdir = ROOT /'_temp' / f'{dsnames}-{time_tag}_lung'  # set by user
figdir = resdir / 'figs'
came.check_dirs(figdir)  # check and make the directory

# Filtering genes (a preprocessing step, optional)
sc.pp.filter_genes(adata_raw1, min_cells=3)
sc.pp.filter_genes(adata_raw2, min_cells=3)


# Inspect classes
if key_class2 is not None:
    group_counts_ori = pd.concat([
        pd.value_counts(adata_raw1.obs[key_class1]),
        pd.value_counts(adata_raw2.obs[key_class2]),
    ], axis=1, keys=dsnames)
else:
    group_counts_ori = pd.value_counts(adata_raw1.obs[key_class1])


#########################################
# the numer of training epochs
# (a recommended setting is 200-400 for whole-graph training, and 80-200 for sub-graph training)
n_epochs = 200

# the training batch size
# When the GPU memory is limited, set 4096 or more if possible.
batch_size = None #4096

# the number of epochs to skip for checkpoint backup
n_pass = 100

# whether to use the single-cell networks
use_scnets = True

# the number of top DEGs to take as the node-features of each cells.
ntop_deg = 50
# the number of top DEGs to take as the graph nodes, which can be directly displayed on the UMAP plot.
ntop_deg_nodes = 50 ### or 250 ? bridge gene node
# the source of the node genes, use both DEGs and HVGs by default
node_source = 'deg,hvg'  # or deg

# whether to take into account the non-1v1 variables as the node features.
# Note that if most of the homologies are non-1v1, better set this as True!
keep_non1v1_feats = True

# reso=0.4 in pipeline.py

came_inputs, (adata1, adata2) = pipeline.preprocess_unaligned(
    adatas,
    key_class=key_class1,
    use_scnets=use_scnets,
    ntop_deg=ntop_deg,
    ntop_deg_nodes=ntop_deg_nodes,
    node_source=node_source,
)

device = torch.device('cuda:1' if torch.cuda.is_available() else 'cpu')
outputs = pipeline.main_for_unaligned(
    **came_inputs,
    df_varmap=df_varmap,
    df_varmap_1v1=df_varmap_1v1,
    dataset_names=dsnames,
    key_class1=key_class1,
    key_class2=key_class2,
    do_normalize=True,
    keep_non1v1_feats=keep_non1v1_feats,
    n_epochs=n_epochs,
    resdir=resdir,
    n_pass=n_pass,
    batch_size=batch_size,
    plot_results=True,
    device = device
)
dpair = outputs['dpair']
trainer = outputs['trainer']
h_dict = outputs['h_dict']
out_cell = outputs['out_cell']
predictor = outputs['predictor']


obs_ids1, obs_ids2 = dpair.obs_ids1, dpair.obs_ids2
obs = dpair.obs
classes = predictor.classes

# adata1
outputs = pipeline.gather_came_results(
    dpair,
    trainer,
    classes=classes,
    keys=(key_class1, key_class2),
    keys_compare=(key_class1, key_class2),
    resdir=resdir,
    checkpoint='last',
    batch_size=None,
)  # `checkpoint` should be either str ("best" or "last")


# In[9]:


newDF = pd.DataFrame(outputs['dpair'].obs['predicted'][adata_raw1.shape[0]:].values, index = adata_raw2.obs_names.values, columns=['predicted'])
newDF.to_csv(resdir / "query_data_predicted_label.csv")

adata_raw2.obs['predicted'] = newDF.values
df = adata_raw2.obs[['cell_ontology_class', 'predicted']]


# In[10]:


# https://github.com/SZJShuffle/pySankey2/blob/master/example/pySankey2_demo.ipynb
import matplotlib.pyplot as plt
import pandas as pd
from pysankey2.datasets import load_fruits
from pysankey2 import Sankey
# df = load_fruits()
sky = Sankey(df,colorMode="global")
fig,ax = sky.plot(figSize=(3,8))
kws={'horizontalalignment':'left'}  ## parameters within text_kws will be passed to plt.text()
###  In this case, we align the left as the starting position of labels. 
fig.savefig("/mnt/disk1/xzhou/data/cross_species/treesparrow/results_data/sankey_heart_Mouse_neonatal_bird.png", bbox_inches="tight", dpi=800)
# plt.savefig("/mnt/disk1/xzhou/data/paper_results/Fig2/figs/UMAP_12S_"+section_id+".png", 
#             bbox_inches='tight',transparent=False,  pad_inches=0.05, facecolor='w', dpi=300) ##pad_inches=0,                            
plt.show()


# In[ ]:




